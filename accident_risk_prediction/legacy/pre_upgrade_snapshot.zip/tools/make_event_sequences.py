"""Cut labelled sequences out of videos using marked collision times.

Every window of ``sequence.length`` frames (sampled at
``frame_extraction.frame_rate``) gets a time-to-event

    TTE = (next event time) - (time of the window's LAST frame)

and a risk label from ``event_labeling.bins`` in config.yaml:

    TTE in [0, 2)  -> 3 high      TTE in [4, 6) -> 1 slight
    TTE in [2, 4)  -> 2 moderate  TTE in [6, 8) -> skipped (ambiguous buffer)
    TTE >= 8 or no upcoming event -> 0 safe

Windows are skipped when they overlap an ignore range, fall inside the
aftermath of an event (``post_event_skip``), or when an ignore range (an edit
cut) lies between the window and the event, because then the true time gap is
unknown.

Split is decided per VIDEO (see utils/events.assign_split), so sequences of
one ride never leak across train/val/test.

Output layout matches the rest of the pipeline::

    <output_root>/<split>/<video_id>_seqNNNN/
        frames/frame_<video_id>_<k>.jpg
        metadata.json
        label.json      {risk_level, ttc_estimate, time_to_event_s, event_type, ...}

Usage
    # preview counts only (fast, no frames written)
    python -m tools.make_event_sequences --config configs/config.yaml --videos data/raw_videos --dry-run
    # write sequences
    python -m tools.make_event_sequences --config configs/config.yaml --videos data/raw_videos
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import shutil
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import cv2

from utils.config import Config, load_config
from utils.events import assign_split, find_videos, fmt_time, load_events

RISK_NAMES = {0: "safe", 1: "slight", 2: "moderate", 3: "high"}
BIN_TO_CLASS = {"slight": 1, "moderate": 2, "high": 3}


@dataclass
class Window:
    end: int                    # index of last sampled frame (0-based)
    start: int
    t_start: float
    t_end: float
    risk: int
    tte: Optional[float]        # None = no upcoming event
    event_type: Optional[str]
    event_time: Optional[float]


# ---------------------------------------------------------------------------
# Labelling logic (pure, no video I/O)
# ---------------------------------------------------------------------------

def label_from_tte(tte: Optional[float], lab: Config) -> Optional[int]:
    """Risk class for a time-to-event, or None if the window must be skipped."""
    if tte is None or tte >= float(lab.safe_min_tte):
        return 0
    for name, (lo, hi) in lab.bins.items():
        if float(lo) <= tte < float(hi):
            return BIN_TO_CLASS[name]
    return None  # ambiguous buffer between slight and safe


def plan_windows(
    n_samples: int, fps: float, seq_len: int, events: List[Dict],
    ignore: List[List[float]], lab: Config,
) -> List[Window]:
    events = sorted(events, key=lambda e: e["time_s"])
    post = float(lab.post_event_skip)
    safe_min = float(lab.safe_min_tte)
    risk_stride = max(1, int(lab.risk_stride))
    safe_stride = max(1, int(lab.safe_stride))

    risky: List[Window] = []
    safe: List[Window] = []
    for end in range(seq_len - 1, n_samples, risk_stride):
        start = end - seq_len + 1
        t_s, t_e = start / fps, end / fps

        if any(t_s <= b and t_e >= a for a, b in ignore):
            continue
        if any(t_e >= ev["time_s"] and t_s <= ev["time_s"] + post for ev in events):
            continue  # window touches an event or its aftermath

        nxt = next((ev for ev in events if ev["time_s"] >= t_e), None)
        tte = None if nxt is None else nxt["time_s"] - t_e
        if tte is not None and tte < safe_min and any(t_e < a and b < nxt["time_s"] for a, b in ignore):
            continue  # an edit cut sits between window and event: gap unknown

        risk = label_from_tte(tte, lab)
        if risk is None:
            continue
        win = Window(end, start, t_s, t_e, risk, tte,
                     nxt["type"] if nxt else None, nxt["time_s"] if nxt else None)
        if risk > 0:
            risky.append(win)
        elif (end - (seq_len - 1)) % safe_stride == 0:
            safe.append(win)

    cap = lab.get("max_safe_per_video")
    if cap is not None and len(safe) > int(cap):
        step = len(safe) / int(cap)
        safe = [safe[int(i * step)] for i in range(int(cap))]  # evenly spread
    return sorted(risky + safe, key=lambda w: w.end)


# ---------------------------------------------------------------------------
# Video I/O
# ---------------------------------------------------------------------------

def video_props(path: Path) -> Tuple[float, int]:
    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        raise IOError(f"Cannot open video: {path}")
    fps = float(cap.get(cv2.CAP_PROP_FPS)) or 30.0
    n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    cap.release()
    return fps, n


def grab_samples(path: Path, src_fps: float, target_fps: float,
                 sample_ids: List[int], size: Tuple[int, int]) -> Dict[int, bytes]:
    """Decode the video once and return JPEG bytes for the requested samples."""
    want: Dict[int, List[int]] = defaultdict(list)       # src frame -> sample ids
    for k in sample_ids:
        want[int(round(k / target_fps * src_fps))].append(k)
    last = max(want) if want else -1

    out: Dict[int, bytes] = {}
    cap = cv2.VideoCapture(str(path))
    idx = 0
    while idx <= last:
        if not cap.grab():
            break
        if idx in want:
            ok, frame = cap.retrieve()
            if ok:
                frame = cv2.resize(frame, size)
                ok, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 95])
                for k in want[idx]:
                    out[k] = buf.tobytes()
        idx += 1
    cap.release()
    return out


def _remove_old(split_root: Path, video_id: str) -> int:
    removed = 0
    for d in split_root.glob(f"{video_id}_seq*"):
        lbl = d / "label.json"
        try:
            src = json.loads(lbl.read_text(encoding="utf-8")).get("label_source")
        except (OSError, ValueError):
            src = None
        if src == "event_tte":  # only delete what this tool created
            shutil.rmtree(d)
            removed += 1
    return removed


def write_sequences(video_id: str, split_root: Path, windows: List[Window],
                    frames: Dict[int, bytes], fps: float, size: Tuple[int, int],
                    video_name: str) -> List[Dict]:
    rows = []
    for n, w in enumerate(windows):
        ids = list(range(w.start, w.end + 1))
        if any(k not in frames for k in ids):
            continue  # video ended early / unreadable frame
        seq_id = f"{video_id}_seq{n:04d}"
        seq_dir = split_root / seq_id
        (seq_dir / "frames").mkdir(parents=True, exist_ok=True)
        names = [f"frame_{video_id}_{k + 1:06d}.jpg" for k in ids]
        for k, name in zip(ids, names):
            (seq_dir / "frames" / name).write_bytes(frames[k])  # unicode-safe

        meta = {
            "sequence_id": seq_id, "video": video_id, "source_file": video_name,
            "start_frame": w.start + 1, "end_frame": w.end + 1,
            "frame_ids": [k + 1 for k in ids], "frame_names": names,
            "fps": fps, "image_size": list(size),
            "start_time_s": round(w.t_start, 3), "end_time_s": round(w.t_end, 3),
        }
        label = {
            "sequence_id": seq_id,
            "risk_level": w.risk,
            # TTC regression target only for risky windows; null for safe
            "ttc_estimate": round(w.tte, 3) if w.risk > 0 else None,
            "time_to_event_s": None if w.tte is None else round(w.tte, 3),
            "event_type": w.event_type,
            "event_time_s": w.event_time,
            "label_source": "event_tte",
        }
        (seq_dir / "metadata.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
        (seq_dir / "label.json").write_text(json.dumps(label, indent=2), encoding="utf-8")
        rows.append({"sequence_id": seq_id, "video": video_name, "risk_level": w.risk,
                     "time_to_event_s": label["time_to_event_s"], "event_type": w.event_type,
                     "start_time_s": meta["start_time_s"], "end_time_s": meta["end_time_s"]})
    return rows


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Make risk-labelled sequences from collision times")
    p.add_argument("--config", required=True)
    p.add_argument("--videos", help="Folder to look up videos whose stored path moved")
    p.add_argument("--events", help="Override events JSON path")
    p.add_argument("--out", help="Override output root")
    p.add_argument("--only", nargs="*", help="Only these file names or video ids")
    p.add_argument("--overwrite", action="store_true", help="Rebuild videos already processed")
    p.add_argument("--dry-run", action="store_true", help="Only print what would be created")
    return p.parse_args()


def main() -> None:
    args = parse_args()
    cfg = load_config(args.config)
    lab = cfg.event_labeling
    data = load_events(args.events or lab.events_file)
    out_root = Path(args.out or lab.output_root)
    target_fps = float(cfg.frame_extraction.frame_rate)
    seq_len = int(cfg.sequence.length)
    size = tuple(int(v) for v in cfg.frame_extraction.resize)
    ratios = dict(cfg.split)
    lookup = {p.name: p for p in find_videos(args.videos)} if args.videos else {}

    counts: Dict[str, Counter] = defaultdict(Counter)
    videos_per_split: Counter = Counter()
    all_rows: List[Dict] = []

    for name, entry in sorted(data["videos"].items()):
        vid = entry["video_id"]
        if args.only and name not in args.only and vid not in args.only:
            continue
        if entry.get("status") != "done":
            print(f"skip {vid}: status={entry.get('status')} (finish marking first)")
            continue
        path = Path(entry["path"]) if entry.get("path") else None
        if path is None or not path.exists():
            path = lookup.get(name)
        if path is None or not path.exists():
            print(f"skip {vid}: video file not found ({name}); pass --videos")
            continue

        split = assign_split(path, vid, entry, ratios)
        split_root = out_root / split
        if not args.dry_run and any(split_root.glob(f"{vid}_seq*")):
            if not args.overwrite:
                print(f"skip {vid}: already built (use --overwrite)")
                continue
            _remove_old(split_root, vid)

        src_fps, n_src = video_props(path)
        n_samples = int(math.floor(n_src / src_fps * target_fps))
        windows = plan_windows(n_samples, target_fps, seq_len,
                               entry.get("events", []), entry.get("ignore", []), lab)
        c = Counter(w.risk for w in windows)
        evs = ", ".join(fmt_time(e["time_s"]) for e in entry.get("events", [])) or "none"
        print(f"{vid:<38} {split:<5} events[{evs}]  "
              + " ".join(f"{RISK_NAMES[k]}={c.get(k, 0)}" for k in range(4)))

        if args.dry_run:
            counts[split].update(c)
            videos_per_split[split] += 1
            continue

        needed = sorted({k for w in windows for k in range(w.start, w.end + 1)})
        frames = grab_samples(path, src_fps, target_fps, needed, size)
        rows = write_sequences(vid, split_root, windows, frames, target_fps, size, name)
        for r in rows:
            r["split"] = split
            counts[split][r["risk_level"]] += 1
        videos_per_split[split] += 1
        all_rows.extend(rows)

    print("\nSequences per split" + (" (dry run)" if args.dry_run else ""))
    print(f"{'split':<6} {'videos':>6} " + " ".join(f"{RISK_NAMES[k]:>9}" for k in range(4)) + f" {'total':>7}")
    for split in ("train", "val", "test"):
        c = counts[split]
        print(f"{split:<6} {videos_per_split[split]:>6} "
              + " ".join(f"{c.get(k, 0):>9}" for k in range(4)) + f" {sum(c.values()):>7}")

    if all_rows:
        summary = write_summary(out_root)
        print(f"\nWrote {len(all_rows)} sequences under {out_root} (index of all: {summary})")


def write_summary(out_root: Path) -> Path:
    """Rebuild summary.csv from every generated label.json (stays correct after --overwrite)."""
    rows = []
    for lbl in sorted(out_root.glob("*/*/label.json")):
        d = json.loads(lbl.read_text(encoding="utf-8"))
        if d.get("label_source") != "event_tte":
            continue
        meta = json.loads((lbl.parent / "metadata.json").read_text(encoding="utf-8"))
        rows.append({
            "sequence_id": d["sequence_id"], "split": lbl.parent.parent.name,
            "video": meta.get("source_file"), "risk_level": d["risk_level"],
            "time_to_event_s": d.get("time_to_event_s"), "event_type": d.get("event_type"),
            "start_time_s": meta.get("start_time_s"), "end_time_s": meta.get("end_time_s"),
        })
    summary = out_root / "summary.csv"
    with summary.open("w", encoding="utf-8-sig", newline="") as fp:
        w = csv.DictWriter(fp, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    return summary


if __name__ == "__main__":
    main()
