"""Cross-Attention Multimodal Fusion.

Contract (MD `implementation_contracts_specification.md`):

    Inputs
      ViT      → [B, 768]
      GNN      → [B, N, 256]
      Temporal → [B, 512]
      Ego      → [B, 64]

    Output
      [B, 512]

Fusion MUST use cross-attention (not naive concatenation). The temporal
embedding acts as the query stream; ViT (global context), GNN (interaction
set), and Ego (vehicle dynamics) act as key/value modalities.
"""
from __future__ import annotations

from typing import Optional

import torch
import torch.nn as nn


class _CrossAttentionBlock(nn.Module):
    def __init__(self, d_model: int, num_heads: int, dropout: float) -> None:
        super().__init__()
        self.cross = nn.MultiheadAttention(
            d_model, num_heads, dropout=dropout, batch_first=True
        )
        self.norm1 = nn.LayerNorm(d_model)
        self.ffn = nn.Sequential(
            nn.Linear(d_model, d_model * 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_model * 2, d_model),
        )
        self.norm2 = nn.LayerNorm(d_model)
        self.drop = nn.Dropout(dropout)

    def forward(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        key_padding_mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        attn_out, _ = self.cross(
            query, key, key, key_padding_mask=key_padding_mask, need_weights=False,
        )
        x = self.norm1(query + self.drop(attn_out))
        x = self.norm2(x + self.drop(self.ffn(x)))
        return x


class CrossAttentionFusion(nn.Module):
    def __init__(
        self,
        d_model: int = 512,
        num_heads: int = 8,
        num_layers: int = 2,
        dropout: float = 0.1,
        vit_dim: int = 768,
        gnn_dim: int = 256,
        temporal_dim: int = 512,
        ego_dim: int = 64,
        output_dim: int = 512,
    ) -> None:
        super().__init__()
        self.d_model = d_model

        # Project each modality into the shared d_model space
        self.proj_vit = nn.Linear(vit_dim, d_model)
        self.proj_gnn = nn.Linear(gnn_dim, d_model)
        self.proj_temp = nn.Linear(temporal_dim, d_model)
        self.proj_ego = nn.Linear(ego_dim, d_model)

        # One cross-attention stack per "external" modality
        self.vit_blocks = nn.ModuleList(
            [_CrossAttentionBlock(d_model, num_heads, dropout) for _ in range(num_layers)]
        )
        self.gnn_blocks = nn.ModuleList(
            [_CrossAttentionBlock(d_model, num_heads, dropout) for _ in range(num_layers)]
        )
        self.ego_blocks = nn.ModuleList(
            [_CrossAttentionBlock(d_model, num_heads, dropout) for _ in range(num_layers)]
        )

        # Final fusion of the three attended streams + temporal query
        self.fuse = nn.Sequential(
            nn.Linear(d_model * 4, d_model * 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_model * 2, output_dim),
        )
        self.norm_out = nn.LayerNorm(output_dim)
        self.output_dim = output_dim

    def forward(
        self,
        vit_embed: Optional[torch.Tensor],
        gnn_node_set: Optional[torch.Tensor],
        gnn_mask: Optional[torch.Tensor],
        temporal_embed: Optional[torch.Tensor],
        ego_embed: Optional[torch.Tensor],
    ) -> torch.Tensor:
        """All modality tensors are batched along dim 0.

        - vit_embed:       [B, 768]    or None
        - gnn_node_set:    [B, N, 256] or None
        - gnn_mask:        [B, N] bool (True = valid) or None
        - temporal_embed:  [B, 512]    or None  (used as query)
        - ego_embed:       [B, 64]     or None
        """
        if temporal_embed is None:
            raise ValueError("temporal_embed required as the fusion query")

        B = temporal_embed.size(0)
        device = temporal_embed.device

        query = self.proj_temp(temporal_embed).unsqueeze(1)        # [B, 1, d]

        # --- ViT branch ---
        if vit_embed is not None:
            vit_kv = self.proj_vit(vit_embed).unsqueeze(1)         # [B, 1, d]
            vit_out = query
            for blk in self.vit_blocks:
                vit_out = blk(vit_out, vit_kv)
        else:
            vit_out = query.new_zeros(B, 1, self.d_model)

        # --- GNN branch ---
        if gnn_node_set is not None:
            gnn_kv = self.proj_gnn(gnn_node_set)                   # [B, N, d]
            kp_mask = (~gnn_mask) if gnn_mask is not None else None
            if kp_mask is not None:
                # Avoid all-masked rows from breaking attention
                all_masked = kp_mask.all(dim=1)
                if all_masked.any():
                    kp_mask = kp_mask.clone()
                    kp_mask[all_masked, 0] = False
            gnn_out = query
            for blk in self.gnn_blocks:
                gnn_out = blk(gnn_out, gnn_kv, key_padding_mask=kp_mask)
        else:
            gnn_out = query.new_zeros(B, 1, self.d_model)

        # --- Ego branch ---
        if ego_embed is not None:
            ego_kv = self.proj_ego(ego_embed).unsqueeze(1)         # [B, 1, d]
            ego_out = query
            for blk in self.ego_blocks:
                ego_out = blk(ego_out, ego_kv)
        else:
            ego_out = query.new_zeros(B, 1, self.d_model)

        joined = torch.cat(
            [query.squeeze(1), vit_out.squeeze(1),
             gnn_out.squeeze(1), ego_out.squeeze(1)],
            dim=-1,
        )
        out = self.fuse(joined)
        return self.norm_out(out)
